# Retrospectiva — Ciclo 2
## DOPO-POOB 2026-1 | Stacking Cups
**Autores:** Andrés Mora — Daniel Camacho


## 1. ¿Cuáles fueron los mini-ciclos definidos? Justifíquenlos.

Se definieron cuatro mini-ciclos, uno por cada requisito funcional del ciclo 2:

**Mini-ciclo 1 — Tower(int cups)**
Constructor que crea una torre con las copas 1 a N sin tapas, con fondo fijo de 20×50 cm. Se separó como primer mini-ciclo porque es la base sobre la que se prueban los demás métodos del ciclo.

**Mini-ciclo 2 — swap**
Intercambio de dos elementos cualesquiera de la torre. Se hizo inmediatamente después del constructor porque es una operación simple y autocontenida, sin dependencias de los métodos siguientes.

**Mini-ciclo 3 — cover**
Reorganización de tapas para que queden sobre su copa correspondiente. Fue el mini-ciclo más complejo: requirió replantear la lógica de `isCovered` para que trabajara con alturas físicas y no con posiciones de índice.

**Mini-ciclo 4 — swapToReduce**
Consulta del intercambio óptimo que reduce la altura de la torre. Se dejó al final porque depende de que `swap` funcione correctamente y de la lógica de altura de la torre.


## 2. ¿Cuál es el estado actual del proyecto en términos de mini-ciclos?

Los cuatro mini-ciclos están implementados y funcionando. El mayor reproceso ocurrió en `cover` y en `isCovered`: la versión inicial usaba posición de índice como criterio de tapado, lo que fallaba cuando había elementos dentro de la copa entre ella y su tapa. Se replanteó la lógica usando acumulación de alturas físicas (`lidTargetIndex`), lo que resolvió el problema correctamente. Los demás mini-ciclos no tuvieron reprocesos significativos.


## 3. ¿Cuál fue el tiempo total invertido por cada uno?

| Integrante      | Horas aproximadas |
|-----------------|-------------------|
| Andrés Mora     | 9 horas           |
| Daniel Camacho  | 8 horas           |

El tiempo estuvo concentrado principalmente en el mini-ciclo 3 (cover), que requirió múltiples iteraciones para encontrar un criterio de tapado físicamente correcto.


## 4. ¿Cuál consideran fue el mayor logro?

El mayor logro fue resolver `cover` de una forma que respeta el estado físico de la torre sin depender del orden de los índices. La solución de acumular alturas desde la base de cada copa (`lidTargetIndex`) es extensible: funciona con cualquier combinación de elementos dentro de la copa, sin importar si están ordenados o no. Fue un ejercicio real de pensar en el modelo del dominio en lugar de en la estructura de datos.


## 5. ¿Cuál fue el mayor problema técnico? ¿Qué hicieron para resolverlo?

El mayor problema fue definir correctamente cuándo una copa está tapada. Las primeras versiones usaban `isCovered` mirando si la tapa estaba en `idx+1` (inmediatamente después en la lista), lo que fallaba cuando había copas más pequeñas dentro. Luego se intentó con anchura de elementos, lo que fallaba con torres desordenadas. La solución final fue acumular la altura de los elementos desde la base de la copa (empezando en 1 cm por la base), y cuando esa suma sobrepasara la altura de la copa, el índice donde se sobrepasa es donde debe estar la tapa. Si la suma llega exacta, la tapa va en el siguiente índice.


## 6. ¿Qué hicieron bien como equipo? ¿Qué se comprometen a mejorar?

**Lo que hicieron bien:** mantener la separación de responsabilidades del ciclo 1, no romper los métodos existentes al agregar los del ciclo 2, y trabajar con el simulador en modo invisible para las pruebas, lo que aceleró la detección de errores lógicos.

**Compromiso de mejora:** planificar con mayor anticipación los criterios de prueba antes de implementar, para no descubrir casos borde durante las pruebas finales. En `cover` hubiera ayudado definir desde el principio qué significa "tapado físicamente" con ejemplos concretos.


## 7. ¿Cuál práctica XP fue la más útil?

El desarrollo en mini-ciclos fue la práctica más útil. Tener `swap` completamente funcional antes de empezar `cover` permitió usarlo con confianza dentro de `swapToReduce`, sin preocuparse por efectos secundarios. Cuando `cover` necesitó rediseño, no afectó los demás métodos porque cada uno tenía sus propias pruebas.


## 8. Referencias

- Sedgewick, R., & Wayne, K. (2011). *Algorithms* (4th ed.). Addison-Wesley. Consultado para la lógica de acumulación en estructuras lineales.
- Oracle. (2024). *Java SE 17 Documentation*. https://docs.oracle.com/en/java/index.html. Referencia principal para el uso de `Arrays.sort` y manejo de arreglos.
- ICPC. (2025). *Problem J: Stacking Cups — ICPC World Finals 2025*. https://icpc.global. Enunciado original del problema que inspiró el simulador.

La referencia más útil fue la documentación oficial de Java, especialmente para el manejo de arreglos y la clase `Arrays`.
