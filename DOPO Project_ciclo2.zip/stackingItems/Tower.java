import javax.swing.JOptionPane;
import java.util.Arrays;

/**
 * Simula una torre de apilamiento de tazas y tapas.
 *
 * MODELO DE APILAMIENTO:
 * La torre mantiene un "nivel de piso" (floorY) que representa la base
 * del elemento actual. Cuando se apila un elemento:
 *
 *   - Si es más ancho que el elemento anterior (o es el primero):
 *     va encima del elemento anterior (floorY sube).
 *   - Si es más angosto que el elemento anterior (cabe dentro):
 *     su base queda al mismo nivel que la base del contenedor más
 *     cercano que lo puede contener. Visualmente está DENTRO de ese contenedor.
 *
 * La altura de la torre es la distancia desde la base del elemento más
 * externo hasta el punto más alto de cualquier elemento.
 *
 * @author AndresMora-DanielCamacho
 * @version 3.0
 */
public class Tower {

    private static final int PX_PER_CM = Cup.PX_PER_CM;
    private static final int TOWER_X   = 30;   // margen izquierdo px
    private static final int TOWER_TOP = 10;   // margen superior px
    private static final int RULER_W   = 8;    // ancho regla px
    private static final int TICK_H    = 2;    // alto marca regla px
    private static final int MAX_ITEMS = 500;

    private int width;
    private int maxHeight;

    /** Lista de elementos en orden de apilamiento (índice 0 = fondo de la torre). */
    private Object[] items;
    private int itemCount;

    private Rectangle   background;
    private Rectangle[] rulerTicks;

    private boolean visible;
    private boolean lastOk;

    /** Centro X de la torre en píxeles (calculado según la copa más grande posible). */
    private int centerX;
    /** Ancho del fondo en píxeles. */
    private int bgWidthPx;

    /**
     * Crea una torre con el ancho y la altura máxima dados.
     *
     * @param width     ancho mínimo en cm
     * @param maxHeight altura máxima en cm
     */
    public Tower(int width, int maxHeight) {
        this.width      = width;
        this.maxHeight  = maxHeight;
        this.lastOk     = true;
        this.items      = new Object[MAX_ITEMS];
        this.itemCount  = 0;
        this.rulerTicks = new Rectangle[maxHeight];

        buildBackground();

        if (fitsOnCanvas()) {
            visible = true;
            showBackground();
        } else {
            visible = false;
        }
    }

    // ---------------------------------------------------------------
    // TAZAS
    // ---------------------------------------------------------------

    /**
     * Agrega una taza a la cima de la torre.
     *
     * @param t número de la taza
     */
    public void pushCup(int t) {
        if (findCup(t) != -1) { fail("Taza " + t + " ya está en la torre."); return; }
        items[itemCount++] = new Cup(t);
        lastOk = true;
        redraw();
    }

    /**
     * Elimina la taza más alta de la lista (y su tapa pegada si la tiene).
     */
    public void popCup() {
        int idx = lastCupIndex();
        if (idx == -1) { fail("No hay tazas en la torre."); return; }
        if (isCovered(idx)) removeAtIndex(idx + 1);
        removeAtIndex(lastCupIndex());
        lastOk = true;
        redraw();
    }

    /**
     * Elimina la taza con el número dado (y su tapa pegada si la tiene).
     *
     * @param t número de la taza
     */
    public void removeCup(int t) {
        int idx = findCup(t);
        if (idx == -1) { fail("Taza " + t + " no está en la torre."); return; }
        if (isCovered(idx)) removeAtIndex(idx + 1);
        removeAtIndex(findCup(t));
        lastOk = true;
        redraw();
    }

    // ---------------------------------------------------------------
    // TAPAS
    // ---------------------------------------------------------------

    /**
     * Agrega una tapa a la cima de la torre.
     *
     * @param t número de la tapa
     */
    public void pushLid(int t) {
        if (findLid(t) != -1) { fail("Tapa " + t + " ya está en la torre."); return; }
        items[itemCount++] = new Lid(t);
        lastOk = true;
        redraw();
    }

    /**
     * Elimina la tapa más alta de la lista.
     */
    public void popLid() {
        int idx = lastLidIndex();
        if (idx == -1) { fail("No hay tapas en la torre."); return; }
        removeAtIndex(idx);
        lastOk = true;
        redraw();
    }

    /**
     * Elimina la tapa con el número dado.
     *
     * @param t número de la tapa
     */
    public void removeLid(int t) {
        int idx = findLid(t);
        if (idx == -1) { fail("Tapa " + t + " no está en la torre."); return; }
        removeAtIndex(idx);
        lastOk = true;
        redraw();
    }

    // ---------------------------------------------------------------
    // REORGANIZAR
    // ---------------------------------------------------------------

    /**
     * Ordena los elementos de mayor a menor número (el menor queda en cima).
     * Si una taza tiene su tapa en la lista, la tapa se pega encima de la taza.
     */
    public void orderTower() {
        hideAll();
        sortByNumberDescending();
        trimToFit();
        lastOk = true;
        redraw();
    }

    /**
     * Invierte el orden actual de todos los elementos (voltea la torre 180°).
     * Todas las copas cambian de orientación (U ↔ ∩).
     * Una copa tapada y su tapa se invierten juntas manteniendo su par.
     */
    public void reverseTower() {
        hideAll();
        reverseItems();
        flipAllCups();
        trimToFit();
        lastOk = true;
        redraw();
    }

    // ---------------------------------------------------------------
    // CICLO 2 — NUEVOS MÉTODOS
    // ---------------------------------------------------------------

    /**
     * Constructor que crea una torre con copas del 1 al cups (sin tapas).
     * El maxHeight se calcula para contener todas las copas apiladas en orden,
     * y el width para la copa más grande.
     * Ej: cups=4 crea las tazas 1, 2, 3 y 4 (altura 1, 3, 5, 7 cm).
     *
     * @param cups número de tazas a crear (>= 1)
     */
    public Tower(int cups) {
        this(20, 50);
        for (int i = cups; i >= 1; i--) {
            items[itemCount++] = new Cup(i);
        }
        lastOk = true;
        redraw();
    }

    /**
     * Intercambia la posición de dos objetos en la torre.
     * Forma amigable: swap("cup", 4, "lid", 4)
     *
     * @param type1 tipo del primer objeto ("cup" o "lid")
     * @param num1  número del primer objeto
     * @param type2 tipo del segundo objeto ("cup" o "lid")
     * @param num2  número del segundo objeto
     */
    public void swap(String type1, int num1, String type2, int num2) {
        swap(new String[]{type1, String.valueOf(num1)},
             new String[]{type2, String.valueOf(num2)});
    }

    /**
     * Intercambia la posición de dos objetos en la torre.
     * Los objetos se identifican por tipo y número: {"cup","4"} o {"lid","4"}.
     * Si alguno de los dos no existe, la operación falla.
     *
     * @param o1 identificador del primer objeto  {tipo, número}
     * @param o2 identificador del segundo objeto {tipo, número}
     */
    public void swap(String[] o1, String[] o2) {
        int idx1 = findItem(o1);
        int idx2 = findItem(o2);
        if (idx1 == -1) { fail("Elemento " + o1[0] + " " + o1[1] + " no está en la torre."); return; }
        if (idx2 == -1) { fail("Elemento " + o2[0] + " " + o2[1] + " no está en la torre."); return; }
        Object tmp  = items[idx1];
        items[idx1] = items[idx2];
        items[idx2] = tmp;
        lastOk = true;
        redraw();
    }

    /**
     * Tapa las tazas que tienen su tapa en la torre.
     * Para cada tapa que tenga su copa en la torre, la mueve paso a paso
     * hasta que isCovered(cupIdx) sea true.
     */
    /**
     * Tapa las tazas que tienen su tapa en la torre.
     * Procesa de menor a mayor número para no desacomodar las más grandes.
     * La tapa se manda al final si está antes de su copa, luego baja 1 a 1
     * hasta que lidTargetIndex indique que está en su lugar físico.
     */
    public void cover() {
        int[] toCover = new int[itemCount];
        int count = 0;
        for (int i = 0; i < itemCount; i++) {
            if (!(items[i] instanceof Cup)) continue;
            int n = ((Cup) items[i]).getNumber();
            if (findLid(n) != -1) toCover[count++] = n;
        }
        if (count == 0) { fail("No hay tazas con tapas para cubrir."); return; }

        Arrays.sort(toCover, 0, count);

        for (int k = 0; k < count; k++) {
            int n = toCover[k];
            int cupIdx = findCup(n);
            int lidIdx = findLid(n);

            // Si la tapa está antes de su copa en la lista, mandarla al final
            if (lidIdx < cupIdx) {
                Object tmp = items[lidIdx];
                for (int j = lidIdx; j < itemCount - 1; j++) items[j] = items[j + 1];
                items[itemCount - 1] = tmp;
            }

            // Bajar la tapa 1 a 1 hasta que esté en su lugar físico
            while (true) {
                cupIdx = findCup(n);
                lidIdx = findLid(n);
                int target = lidTargetIndex(cupIdx);
                if (lidIdx == target) break;
                Object tmp = items[lidIdx];
                items[lidIdx] = items[lidIdx - 1];
                items[lidIdx - 1] = tmp;
            }
        }
        lastOk = true;
        redraw();
    }
    /**
     * Consulta qué intercambio de dos elementos reduciría la altura de la torre.
     * Prueba todos los pares posibles y retorna el par que produce la mayor reducción.
     * Si ningún intercambio reduce la altura, retorna un arreglo vacío.
     *
     * @return String[][] con los dos identificadores {tipo,número}, o vacío si no hay mejora.
     *         Ej: {{"cup","4"},{"lid","4"}}
     */
    public String[][] swapToReduce() {
        int currentH = stackHeight();
        int bestGain = 0;
        int bestI = -1, bestJ = -1;

        for (int i = 0; i < itemCount; i++) {
            for (int j = i + 1; j < itemCount; j++) {
                // Intercambiar temporalmente
                Object tmp = items[i]; items[i] = items[j]; items[j] = tmp;
                int newH = stackHeight();
                int gain = currentH - newH;
                // Revertir
                tmp = items[i]; items[i] = items[j]; items[j] = tmp;

                if (gain > bestGain) {
                    bestGain = gain;
                    bestI = i;
                    bestJ = j;
                }
            }
        }

        if (bestI == -1) return new String[0][0];

        return new String[][] {
            { typeOf(bestI), String.valueOf(numberOf(bestI)) },
            { typeOf(bestJ), String.valueOf(numberOf(bestJ)) }
        };
    }

    // ---------------------------------------------------------------
    // CICLO 1 — REORGANIZAR (continuación)
    // ---------------------------------------------------------------

    /**
     * Retorna la altura efectiva de la torre en cm.
     * Es la altura desde la base de la torre hasta el punto más alto.
     *
     * @return altura en cm
     */
    public int height() { return stackHeight(); }

    /**
     * Retorna los números de las tazas que tienen su tapa pegada
     * (tapa inmediatamente en posición i+1), ordenados de menor a mayor.
     *
     * @return int[] con los números de tazas tapadas
     */
    public int[] lidedCups() {
        int count = 0;
        for (int i = 0; i < itemCount; i++) {
            if (items[i] instanceof Cup && isCovered(i)) count++;
        }
        int[] result = new int[count];
        int   pos    = 0;
        for (int i = 0; i < itemCount; i++) {
            if (items[i] instanceof Cup && isCovered(i))
                result[pos++] = ((Cup) items[i]).getNumber();
        }
        Arrays.sort(result);
        return result;
    }

    /**
     * Retorna los elementos apilados como {tipo, número}, de base a cima.
     *
     * @return String[][] de elementos
     */
    public String[][] stackingItems() {
        String[][] result = new String[itemCount][2];
        for (int i = 0; i < itemCount; i++) {
            if (items[i] instanceof Cup) {
                result[i][0] = "cup"; result[i][1] = String.valueOf(((Cup)items[i]).getNumber());
            } else {
                result[i][0] = "lid"; result[i][1] = String.valueOf(((Lid)items[i]).getNumber());
            }
        }
        return result;
    }

    // ---------------------------------------------------------------
    // VISIBILIDAD
    // ---------------------------------------------------------------

    /** Hace visible el simulador. */
    public void makeVisible() {
        if (!fitsOnCanvas()) return;
        visible = true;
        showBackground();
        redraw();
    }

    /** Hace invisible el simulador. */
    public void makeInvisible() {
        visible = false;
        hideAll();
        background.makeInvisible();
        for (Rectangle t : rulerTicks) { if (t != null) t.makeInvisible(); }
    }

    /** Termina el simulador. */
    public void exit() { System.exit(0); }

    /**
     * Indica si la última operación fue exitosa.
     * @return true si tuvo éxito
     */
    public boolean ok() { return lastOk; }

    // ---------------------------------------------------------------
    // DIBUJO — núcleo del simulador
    // ---------------------------------------------------------------

    /**
     * Redibuja todos los elementos. Detecta si la torre está invertida
     * (alguna copa está upsideDown) y usa la física correspondiente.
     */
    private void redraw() {
        hideAll();
        if (!visible) return;
        if (isInverted()) drawInverted();
        else              drawNormal();
    }

    /**
     * Torre normal (U): gravedad hacia abajo.
     * Recorre lista de fondo (0) a cima (N-1).
     * Copas U son contenedores hacia arriba.
     */
    private void drawNormal() {
        int bottomPx    = TOWER_TOP + maxHeight * PX_PER_CM;
        int wallPx      = Cup.WALL;

        int[]     stkBaseY   = new int[MAX_ITEMS];
        int[]     stkTopY    = new int[MAX_ITEMS];
        int[]     stkWidth   = new int[MAX_ITEMS];
        boolean[] stkIsCup   = new boolean[MAX_ITEMS];
        int[]     stkIdx     = new int[MAX_ITEMS];
        int       stkSize    = 0;
        int       highTopY   = bottomPx; // punto más alto visto (menor Y = más arriba)

        for (int i = 0; i < itemCount; i++) {
            int w = widthPxOf(i);
            int h = heightPxOf(i);

            int lastPoppedTopY = -1;
            while (stkSize > 0) {
                boolean canContain = stkIsCup[stkSize-1]
                    && !((Cup) items[stkIdx[stkSize-1]]).isUpsideDown();
                int interior = canContain ? stkWidth[stkSize-1] - 2*wallPx : 0;
                if (w > interior) { lastPoppedTopY = stkTopY[stkSize-1]; stkSize--; }
                else break;
            }

            int baseY;
            if      (stkSize > 0 && lastPoppedTopY != -1) baseY = lastPoppedTopY;
            else if (stkSize > 0)                          baseY = stkBaseY[stkSize-1] - wallPx;
            else if (lastPoppedTopY != -1)                 baseY = highTopY;
            else                                           baseY = bottomPx;

            int topY = baseY - h;
            placeElement(i, centerX - w/2, topY);
            if (topY < highTopY) highTopY = topY;

            stkBaseY[stkSize] = baseY; stkTopY[stkSize] = topY;
            stkWidth[stkSize] = w;     stkIsCup[stkSize] = (items[i] instanceof Cup);
            stkIdx  [stkSize] = i;     stkSize++;
        }
    }

    /**
     * Torre invertida (∩): la lista está al revés y las copas están boca abajo.
     * La gravedad sigue siendo hacia abajo — todo apoya desde el fondo.
     * Recorre la lista de índice 0 (ahora la cima original = lo más pequeño)
     * a N-1 (el fondo original = lo más grande).
     * Una copa ∩ contiene elementos dentro de su apertura inferior:
     * su techo interior = topY + WALL, y los elementos internos cuelgan desde ahí hacia abajo.
     */
    private void drawInverted() {
        int bottomPx = TOWER_TOP + maxHeight * PX_PER_CM;
        int wallPx   = Cup.WALL;

        int[]     stkBaseY  = new int[MAX_ITEMS];
        int[]     stkTopY   = new int[MAX_ITEMS];
        int[]     stkWidth  = new int[MAX_ITEMS];
        boolean[] stkIsCup  = new boolean[MAX_ITEMS];
        int[]     stkIdx    = new int[MAX_ITEMS];
        int       stkSize   = 0;
        int       highTopY  = bottomPx;

        for (int i = 0; i < itemCount; i++) {
            int w = widthPxOf(i);
            int h = heightPxOf(i);

            int lastPoppedTopY = -1;
            while (stkSize > 0) {
                // Copa ∩ puede contener cosas debajo de ella
                boolean canContain = stkIsCup[stkSize-1]
                    && ((Cup) items[stkIdx[stkSize-1]]).isUpsideDown();
                int interior = canContain ? stkWidth[stkSize-1] - 2*wallPx : 0;
                if (w > interior) { lastPoppedTopY = stkTopY[stkSize-1]; stkSize--; }
                else break;
            }

            int baseY;
            if      (stkSize > 0 && lastPoppedTopY != -1) baseY = lastPoppedTopY;
            else if (stkSize > 0) {
                // Primer elemento dentro de una copa ∩:
                // la base interior está en topY del contenedor + WALL (el techo de la ∩)
                baseY = stkTopY[stkSize-1] + wallPx + h;
            }
            else if (lastPoppedTopY != -1)                 baseY = highTopY;
            else                                           baseY = bottomPx;

            int topY = baseY - h;
            placeElement(i, centerX - w/2, topY);
            if (topY < highTopY) highTopY = topY;

            stkBaseY[stkSize] = baseY; stkTopY[stkSize] = topY;
            stkWidth[stkSize] = w;     stkIsCup[stkSize] = (items[i] instanceof Cup);
            stkIdx  [stkSize] = i;     stkSize++;
        }
    }

    /**
     * Retorna true si la torre está en estado invertido.
     * Se determina si la primera copa de la lista está upsideDown.
     */
    private boolean isInverted() {
        for (int i = 0; i < itemCount; i++) {
            if (items[i] instanceof Cup) return ((Cup) items[i]).isUpsideDown();
        }
        return false;
    }

    /** Mueve y hace visible el elemento i en la posición dada. */
    private void placeElement(int i, int x, int y) {
        if (items[i] instanceof Cup) {
            Cup c = (Cup) items[i];
            c.moveTo(x, y);
            c.makeVisible();
        } else {
            Lid l = (Lid) items[i];
            l.moveTo(x, y);
            l.makeVisible();
        }
    }

    // ---------------------------------------------------------------
    // ALTURA EFECTIVA DE LA TORRE
    // ---------------------------------------------------------------

    /**
     * Calcula la altura efectiva de la torre en cm usando la misma
     * lógica de contenedores que redraw().
     *
     * @return altura de la torre en cm
     */
    private int stackHeight() {
        if (itemCount == 0) return 0;
        if (isInverted()) return stackHeightInverted();

        int[] stkBase  = new int[MAX_ITEMS];
        int[] stkTop   = new int[MAX_ITEMS];
        int[] stkWidth = new int[MAX_ITEMS];
        int[] stkIdx   = new int[MAX_ITEMS];
        boolean[] stkIsCup = new boolean[MAX_ITEMS];
        int stkSize = 0, maxTop = 0;

        for (int i = 0; i < itemCount; i++) {
            int w = widthCmOf(i), h = heightCmOf(i), wall = 1;
            int lastPoppedTop = -1;
            while (stkSize > 0) {
                boolean canContain = stkIsCup[stkSize-1]
                    && !((Cup) items[stkIdx[stkSize-1]]).isUpsideDown();
                int interior = canContain ? stkWidth[stkSize-1] - 2*wall : 0;
                if (w > interior) { lastPoppedTop = stkTop[stkSize-1]; stkSize--; }
                else break;
            }
            int base;
            if      (stkSize > 0 && lastPoppedTop != -1) base = lastPoppedTop;
            else if (stkSize > 0)                         base = stkBase[stkSize-1] + wall;
            else if (lastPoppedTop != -1)                 base = maxTop;
            else                                          base = maxTop;
            int top = base + h;
            if (top > maxTop) maxTop = top;
            stkBase[stkSize]=base; stkTop[stkSize]=top;
            stkWidth[stkSize]=w;   stkIsCup[stkSize]=(items[i] instanceof Cup);
            stkIdx[stkSize]=i;     stkSize++;
        }
        return maxTop;
    }

    /** Altura de la torre invertida: misma lógica pero recorriendo al revés. */
    private int stackHeightInverted() {
        int[] stkBase  = new int[MAX_ITEMS];
        int[] stkTop   = new int[MAX_ITEMS];
        int[] stkWidth = new int[MAX_ITEMS];
        int[] stkIdx   = new int[MAX_ITEMS];
        boolean[] stkIsCup = new boolean[MAX_ITEMS];
        int stkSize = 0, maxTop = 0;

        for (int i = itemCount - 1; i >= 0; i--) {
            int w = widthCmOf(i), h = heightCmOf(i), wall = 1;
            int lastPopped = -1;
            while (stkSize > 0) {
                boolean canContain = stkIsCup[stkSize-1]
                    && ((Cup) items[stkIdx[stkSize-1]]).isUpsideDown();
                int interior = canContain ? stkWidth[stkSize-1] - 2*wall : 0;
                if (w > interior) { lastPopped = stkTop[stkSize-1]; stkSize--; }
                else break;
            }
            int base;
            if      (stkSize > 0 && lastPopped != -1) base = lastPopped;
            else if (stkSize > 0)                      base = stkBase[stkSize-1] + wall;
            else if (lastPopped != -1)                 base = maxTop;
            else                                       base = maxTop;
            int top = base + h;
            if (top > maxTop) maxTop = top;
            stkBase[stkSize]=base; stkTop[stkSize]=top;
            stkWidth[stkSize]=w;   stkIsCup[stkSize]=(items[i] instanceof Cup);
            stkIdx[stkSize]=i;     stkSize++;
        }
        return maxTop;
    }

    // ---------------------------------------------------------------
    // MÉTODOS PRIVADOS DE APOYO
    // ---------------------------------------------------------------

    /** Ancho en píxeles del elemento i. */
    private int widthPxOf(int i) {
        if (items[i] instanceof Cup) return ((Cup) items[i]).getWidthPx();
        return ((Lid) items[i]).getWidthPx();
    }

    /** Altura en píxeles del elemento i. */
    private int heightPxOf(int i) {
        if (items[i] instanceof Cup) return ((Cup) items[i]).getHeightPx();
        return Lid.HEIGHT_CM * PX_PER_CM;
    }

    /** Ancho en cm del elemento i. */
    private int widthCmOf(int i) {
        if (items[i] instanceof Cup) return ((Cup) items[i]).getWidthCm();
        return ((Lid) items[i]).getWidthCm();
    }

    /** Altura en cm del elemento i. */
    private int heightCmOf(int i) {
        if (items[i] instanceof Cup) return ((Cup) items[i]).getHeightCm();
        return Lid.HEIGHT_CM;
    }

    /**
     * Calcula el índice donde debe quedar la tapa para tapar físicamente la copa en idx.
     * Acumula alturas desde la base (1cm): si al sumar el elemento i sobrepasa la altura
     * de la copa, la tapa va en i. Si la completa exacta, va en i+1.
     *
     * @param idx índice de la copa
     * @return índice objetivo para la tapa
     */
    private int lidTargetIndex(int idx) {
        if (!(items[idx] instanceof Cup)) return -1;
        Cup cup = (Cup) items[idx];
        int accumulated = 1;
        for (int i = idx + 1; i < itemCount; i++) {
            int next = accumulated + heightCmOf(i);
            if (next > cup.getHeightCm())  return i;
            if (next == cup.getHeightCm()) return i + 1;
            accumulated = next;
        }
        return itemCount;
    }

    /**
     * Indica si la taza en idx está tapada físicamente.
     * Usa lidTargetIndex para saber dónde debe estar la tapa.
     *
     * @param idx índice de la taza
     * @return true si está tapada
     */
    private boolean isCovered(int idx) {
        if (idx < 0 || idx >= itemCount)  return false;
        if (!(items[idx] instanceof Cup)) return false;
        int target = lidTargetIndex(idx);
        if (target < 0 || target >= itemCount) return false;
        return (items[target] instanceof Lid)
            && ((Lid) items[target]).getNumber() == ((Cup) items[idx]).getNumber();
    }

    /**
     * Ordena la lista de mayor a menor número usando inserción.
     * Las tapas que pertenecen a tazas presentes se pegan encima de su taza.
     */
    private void sortByNumberDescending() {
        int cupCount = 0, lidCount = 0;
        Cup[] cups = new Cup[itemCount];
        Lid[] lids = new Lid[itemCount];
        for (int i = 0; i < itemCount; i++) {
            if (items[i] instanceof Cup) cups[cupCount++] = (Cup) items[i];
            else                          lids[lidCount++] = (Lid) items[i];
        }

        // Ordenar tazas descendente
        for (int i = 1; i < cupCount; i++) {
            Cup key = cups[i]; int j = i - 1;
            while (j >= 0 && cups[j].getNumber() < key.getNumber()) { cups[j+1]=cups[j]; j--; }
            cups[j+1] = key;
        }
        // Ordenar tapas descendente
        for (int i = 1; i < lidCount; i++) {
            Lid key = lids[i]; int j = i - 1;
            while (j >= 0 && lids[j].getNumber() < key.getNumber()) { lids[j+1]=lids[j]; j--; }
            lids[j+1] = key;
        }

        // Reconstruir: tazas de mayor a menor, pegando su tapa si existe
        boolean[] lidUsed = new boolean[lidCount];
        itemCount = 0;
        int li = 0;
        for (int ci = 0; ci < cupCount; ci++) {
            Cup cup = cups[ci];
            // Tapas sueltas más grandes que esta taza van antes
            while (li < lidCount && !lidUsed[li]) {
                boolean belongsToCup = false;
                for (int k = 0; k < cupCount; k++) {
                    if (cups[k].getNumber() == lids[li].getNumber()) { belongsToCup = true; break; }
                }
                if (belongsToCup) { li++; continue; }
                if (lids[li].getNumber() > cup.getNumber()) {
                    items[itemCount++] = lids[li]; lidUsed[li] = true; li++;
                } else break;
            }
            items[itemCount++] = cup;
            // Pegar tapa si existe
            for (int k = 0; k < lidCount; k++) {
                if (!lidUsed[k] && lids[k].getNumber() == cup.getNumber()) {
                    items[itemCount++] = lids[k]; lidUsed[k] = true; break;
                }
            }
        }
        // Tapas restantes sin taza
        for (int k = 0; k < lidCount; k++) {
            if (!lidUsed[k]) items[itemCount++] = lids[k];
        }
    }

    /** Invierte el arreglo de items. */
    private void reverseItems() {
        for (int i = 0; i < itemCount / 2; i++) {
            Object tmp = items[i]; items[i] = items[itemCount-1-i]; items[itemCount-1-i] = tmp;
        }
    }

    /** Voltea la orientación de todas las copas (U ↔ ∩). */
    private void flipAllCups() {
        for (int i = 0; i < itemCount; i++) {
            if (items[i] instanceof Cup) ((Cup) items[i]).flip();
        }
    }

    /** Elimina elementos desde la cima hasta que la altura quepa. */
    private void trimToFit() {
        while (stackHeight() > maxHeight && itemCount > 0) items[--itemCount] = null;
    }

    /** Construye el fondo y la regla. El ancho se adapta a la copa más grande posible. */
    private void buildBackground() {
        // Copa más grande que cabe: número n donde 2n-1 <= maxHeight → n = (maxHeight+1)/2
        int maxCupNum = (maxHeight + 1) / 2;
        // Ancho de esa copa en px
        bgWidthPx = Math.max(width * PX_PER_CM, maxCupNum * 2 * PX_PER_CM);
        centerX   = TOWER_X + bgWidthPx / 2;
        int hPx   = maxHeight * PX_PER_CM;

        background = new Rectangle();
        background.changeSize(hPx, bgWidthPx + RULER_W);
        background.changeColor("black");
        background.moveHorizontal(TOWER_X - 70);
        background.moveVertical(TOWER_TOP - 15);

        for (int cm = 1; cm <= maxHeight; cm++) {
            Rectangle tick = new Rectangle();
            tick.changeSize(TICK_H, RULER_W);
            tick.changeColor("white");
            tick.moveHorizontal((TOWER_X + bgWidthPx) - 70);
            tick.moveVertical((TOWER_TOP + hPx - cm * PX_PER_CM) - 15);
            rulerTicks[cm - 1] = tick;
        }
    }

    /** Muestra fondo y regla. */
    private void showBackground() {
        background.makeVisible();
        for (Rectangle t : rulerTicks) { if (t != null) t.makeVisible(); }
    }

    /** Oculta todos los elementos. */
    private void hideAll() {
        for (int i = 0; i < itemCount; i++) {
            if      (items[i] instanceof Cup) ((Cup)items[i]).makeInvisible();
            else if (items[i] instanceof Lid) ((Lid)items[i]).makeInvisible();
        }
    }

    /** Elimina el elemento en idx y compacta el arreglo. */
    private void removeAtIndex(int idx) {
        if (idx < 0 || idx >= itemCount) return;
        if      (items[idx] instanceof Cup) ((Cup)items[idx]).makeInvisible();
        else if (items[idx] instanceof Lid) ((Lid)items[idx]).makeInvisible();
        for (int i = idx; i < itemCount - 1; i++) items[i] = items[i+1];
        items[--itemCount] = null;
    }

    /** Índice de la taza con el número dado, o -1. */
    private int findCup(int n) {
        for (int i = 0; i < itemCount; i++)
            if (items[i] instanceof Cup && ((Cup)items[i]).getNumber() == n) return i;
        return -1;
    }

    /** Índice de la tapa con el número dado, o -1. */
    private int findLid(int n) {
        for (int i = 0; i < itemCount; i++)
            if (items[i] instanceof Lid && ((Lid)items[i]).getNumber() == n) return i;
        return -1;
    }

    /**
     * Índice del elemento identificado por {tipo, número}, o -1.
     *
     * @param id {"cup","n"} o {"lid","n"}
     * @return índice en la lista, o -1
     */
    private int findItem(String[] id) {
        int n = Integer.parseInt(id[1]);
        if (id[0].equals("cup")) return findCup(n);
        if (id[0].equals("lid")) return findLid(n);
        return -1;
    }

    /** Tipo del elemento en la posición dada ("cup" o "lid"). */
    private String typeOf(int i) {
        return (items[i] instanceof Cup) ? "cup" : "lid";
    }

    /** Número del elemento en la posición dada. */
    private int numberOf(int i) {
        if (items[i] instanceof Cup) return ((Cup)items[i]).getNumber();
        return ((Lid)items[i]).getNumber();
    }

    /** Índice de la última taza, o -1. */
    private int lastCupIndex() {
        for (int i = itemCount - 1; i >= 0; i--)
            if (items[i] instanceof Cup) return i;
        return -1;
    }

    /** Índice de la última tapa, o -1. */
    private int lastLidIndex() {
        for (int i = itemCount - 1; i >= 0; i--)
            if (items[i] instanceof Lid) return i;
        return -1;
    }

    /** ¿Cabe la torre en el canvas? */
    private boolean fitsOnCanvas() {
        return (maxHeight * PX_PER_CM + TOWER_TOP) <= 600
            && (bgWidthPx + TOWER_X + RULER_W)     <= 600;
    }

    /** Marca lastOk=false y muestra mensaje si visible. */
    private void fail(String msg) {
        lastOk = false;
        if (visible) JOptionPane.showMessageDialog(null, msg,
            "Simulador de Torre", JOptionPane.WARNING_MESSAGE);
    }
}
