import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * Pruebas unitarias del Ciclo 2 - Stacking Cups (DOPO-POOB 2026-1).
 * Todas las pruebas corren en modo invisible.
 *
 * @author AndresMora-DanielCamacho
 * @version 1.0
 */
public class TowerC2Test {

    private Tower tower;

    /**
     * Constructor por defecto.
     */
    public TowerC2Test() {
    }

    /**
     * Inicializa una torre invisible antes de cada prueba.
     */
    @BeforeEach
    public void setUp() {
        tower = new Tower(20, 50);
        tower.makeInvisible();
    }

    /**
     * Limpieza después de cada prueba.
     */
    @AfterEach
    public void tearDown() {
        tower = null;
    }

    /**
     * Tower(cups) crea exactamente N tazas sin tapas.
     */
    @Test
    public void testTowerCupsCreatesNCups() {
        Tower t = new Tower(4);
        t.makeInvisible();
        String[][] items = t.stackingItems();
        assertEquals(4, items.length);
        for (String[] item : items) {
            assertEquals("cup", item[0]);
        }
        assertTrue(t.ok());
    }

    /**
     * Tower(cups) crea las tazas del 1 al N.
     */
    @Test
    public void testTowerCupsCreatesCorrectNumbers() {
        Tower t = new Tower(5);
        t.makeInvisible();
        String[][] items = t.stackingItems();
        boolean hasOne = false, hasFive = false;
        for (String[] item : items) {
            if (item[0].equals("cup") && item[1].equals("1")) hasOne = true;
            if (item[0].equals("cup") && item[1].equals("5")) hasFive = true;
        }
        assertTrue(hasOne);
        assertTrue(hasFive);
    }

    /**
     * Tower(cups) con N=1 crea exactamente una taza.
     */
    @Test
    public void testTowerCupsOneCup() {
        Tower t = new Tower(1);
        t.makeInvisible();
        assertEquals(1, t.stackingItems().length);
        assertTrue(t.ok());
    }

    /**
     * Tower(cups) apila la taza más grande en la base.
     */
    @Test
    public void testTowerCupsLargestAtBottom() {
        Tower t = new Tower(6);
        t.makeInvisible();
        String[][] items = t.stackingItems();
        assertEquals("6", items[0][1]);
        assertEquals("1", items[items.length - 1][1]);
    }

    /**
     * swap intercambia correctamente dos tazas existentes.
     */
    @Test
    public void testSwapTwoCups() {
        tower.pushCup(3);
        tower.pushCup(5);
        tower.swap("cup", 3, "cup", 5);
        assertTrue(tower.ok());
        String[][] items = tower.stackingItems();
        assertEquals("5", items[0][1]);
        assertEquals("3", items[1][1]);
    }

    /**
     * swap entre una taza y su tapa los intercambia.
     */
    @Test
    public void testSwapCupAndLid() {
        tower.pushCup(4);
        tower.pushLid(4);
        tower.swap("cup", 4, "lid", 4);
        assertTrue(tower.ok());
        String[][] items = tower.stackingItems();
        assertEquals("lid", items[0][0]);
        assertEquals("cup", items[1][0]);
    }

    /**
     * swap con un elemento inexistente falla y ok() queda en false.
     */
    @Test
    public void testSwapNonExistentFails() {
        tower.pushCup(2);
        tower.swap("cup", 2, "cup", 99);
        assertFalse(tower.ok());
    }

    /**
     * swap con ambos elementos inexistentes falla.
     */
    @Test
    public void testSwapBothNonExistentFails() {
        tower.swap("cup", 1, "lid", 1);
        assertFalse(tower.ok());
    }

    /**
     * swap no modifica otros elementos de la torre.
     */
    @Test
    public void testSwapKeepsOtherElements() {
        tower.pushCup(2);
        tower.pushCup(4);
        tower.pushCup(6);
        tower.swap("cup", 2, "cup", 6);
        assertTrue(tower.ok());
        assertEquals("4", tower.stackingItems()[1][1]);
    }

    /**
     * cover tapa una copa cuando su tapa está encima en la lista.
     */
    @Test
    public void testCoverLidAboveCup() {
        tower.pushCup(4);
        tower.pushCup(2);
        tower.pushLid(4);
        tower.cover();
        assertTrue(tower.ok());
        int[] lided = tower.lidedCups();
        assertEquals(1, lided.length);
        assertEquals(4, lided[0]);
    }

    /**
     * cover tapa una copa cuando su tapa está debajo en la lista.
     */
    @Test
    public void testCoverLidBelowCup() {
        tower.pushLid(5);
        tower.pushCup(5);
        tower.cover();
        assertTrue(tower.ok());
        int[] lided = tower.lidedCups();
        assertEquals(1, lided.length);
        assertEquals(5, lided[0]);
    }

    /**
     * cover sin tapas en la torre falla.
     */
    @Test
    public void testCoverNoLidsFails() {
        tower.pushCup(3);
        tower.pushCup(5);
        tower.cover();
        assertFalse(tower.ok());
    }

    /**
     * cover en torre vacía falla.
     */
    @Test
    public void testCoverEmptyTowerFails() {
        tower.cover();
        assertFalse(tower.ok());
    }

    /**
     * cover con múltiples copas y tapas las tapa todas.
     */
    @Test
    public void testCoverMultiple() {
        tower.pushCup(6);
        tower.pushCup(4);
        tower.pushCup(5);
        tower.pushLid(4);
        tower.pushCup(7);
        tower.pushLid(6);
        tower.cover();
        assertTrue(tower.ok());
        assertEquals(2, tower.lidedCups().length);
    }

    /**
     * cover solo tapa las copas que tienen tapa en la torre.
     */
    @Test
    public void testCoverOnlyCupsWithLids() {
        tower.pushCup(3);
        tower.pushCup(5);
        tower.pushLid(3);
        tower.cover();
        assertTrue(tower.ok());
        int[] lided = tower.lidedCups();
        assertEquals(1, lided.length);
        assertEquals(3, lided[0]);
    }

    /**
     * swapToReduce sobre torre ordenada retorna vacío.
     */
    @Test
    public void testSwapToReduceNoImprovement() {
        Tower t = new Tower(4);
        t.makeInvisible();
        assertEquals(0, t.swapToReduce().length);
    }

    /**
     * swapToReduce encuentra una mejora y retorna dos identificadores.
     */
    @Test
    public void testSwapToReduceFindsImprovement() {
        tower.pushCup(1);
        tower.pushCup(5);
        String[][] result = tower.swapToReduce();
        assertEquals(2, result.length);
        assertEquals(2, result[0].length);
        assertTrue(tower.ok());
    }

    /**
     * swapToReduce con un solo elemento retorna vacío.
     */
    @Test
    public void testSwapToReduceSingleElement() {
        tower.pushCup(3);
        assertEquals(0, tower.swapToReduce().length);
    }

    /**
     * swapToReduce no modifica la torre.
     */
    @Test
    public void testSwapToReduceDoesNotModify() {
        tower.pushCup(2);
        tower.pushCup(4);
        String[][] before = tower.stackingItems();
        tower.swapToReduce();
        String[][] after = tower.stackingItems();
        assertEquals(before[0][1], after[0][1]);
        assertEquals(before[1][1], after[1][1]);
    }

    /**
     * Aplicar el swap sugerido por swapToReduce reduce o mantiene la altura.
     */
    @Test
    public void testSwapToReduceActuallyReduces() {
        tower.pushCup(1);
        tower.pushCup(5);
        int heightBefore = tower.height();
        String[][] best = tower.swapToReduce();
        if (best.length == 2) {
            tower.swap(best[0], best[1]);
            assertTrue(tower.height() <= heightBefore);
        }
    }
}
