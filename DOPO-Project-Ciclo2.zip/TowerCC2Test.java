/**
 * Propuesta de casos de prueba colectivos - Ciclo 2 (DOPO-POOB 2026-1).
 * Formato: testNombreDelCaso_Iniciales()
 * Cada caso incluye la justificación del escenario probado.
 *
 * @author AndresMora-DanielCamacho
 * @version 1.0
 */
public class TowerCC2Test {

    // Tower(int cups) — AM, DC

    /**
     * Tower(cups) con N grande crea la taza N como base y la taza 1 en la cima.
     * Verifica que el orden de apilamiento sea de mayor a menor.
     * AM
     */
    public static void testTowerCupsLargestAtBottom_AM() {
        Tower t = new Tower(6);
        t.makeInvisible();
        String[][] items = t.stackingItems();
        assert items[0][1].equals("6") : "La taza 6 debe estar en la base (índice 0)";
        assert items[items.length - 1][1].equals("1") : "La taza 1 debe estar en la cima";
    }

    /**
     * Tower(cups) no incluye tapas en la torre inicial.
     * El enunciado pide solo copas, sin tapas.
     * DC
     */
    public static void testTowerCupsNoLids_DC() {
        Tower t = new Tower(3);
        t.makeInvisible();
        for (String[] item : t.stackingItems()) {
            assert item[0].equals("cup") : "No debe haber tapas en Tower(cups)";
        }
    }

    // swap — AM, DC

    /**
     * Después de swap, ok() es true y los elementos realmente intercambiaron posición.
     * AM
     */
    public static void testSwapVerifyPositions_AM() {
        Tower t = new Tower(20, 50);
        t.makeInvisible();
        t.pushCup(2);
        t.pushCup(4);
        t.pushCup(6);
        t.swap("cup", 2, "cup", 6);
        assert t.ok();
        String[][] items = t.stackingItems();
        assert items[0][1].equals("6") : "cup6 debe estar donde estaba cup2";
        assert items[2][1].equals("2") : "cup2 debe estar donde estaba cup6";
    }

    /**
     * swap de un elemento consigo mismo no cambia nada pero ok() es true.
     * DC
     */
    public static void testSwapSameElement_DC() {
        Tower t = new Tower(20, 50);
        t.makeInvisible();
        t.pushCup(3);
        t.pushCup(5);
        String[][] before = t.stackingItems();
        t.swap("cup", 3, "cup", 3);
        assert t.ok();
        String[][] after = t.stackingItems();
        assert before[0][1].equals(after[0][1]);
        assert before[1][1].equals(after[1][1]);
    }

    /**
     * swap entre taza y tapa del mismo número y luego cover() sigue funcionando.
     * Verifica que cover() sea robusto ante órdenes inesperados.
     * AM
     */
    public static void testSwapThenCover_AM() {
        Tower t = new Tower(20, 50);
        t.makeInvisible();
        t.pushCup(4);
        t.pushLid(4);
        t.swap("cup", 4, "lid", 4);  // lid abajo, cup arriba
        t.cover();
        assert t.ok();
        int[] lided = t.lidedCups();
        assert lided.length == 1 && lided[0] == 4;
    }

    // cover — AM, DC

    /**
     * cover con copa y tapa ya en la posición correcta no mueve nada (ok en true).
     * DC
     */
    public static void testCoverAlreadyCovered_DC() {
        Tower t = new Tower(20, 50);
        t.makeInvisible();
        t.pushCup(3);
        t.pushLid(3);
        // Ya está tapada físicamente
        int heightBefore = t.height();
        t.cover();
        assert t.ok();
        assert t.height() == heightBefore : "La altura no debe cambiar si ya estaba tapada";
    }

    /**
     * cover con varias copas anidadas y una sola tapa solo tapa la copa correcta.
     * AM
     */
    public static void testCoverNestedCupsOneLid_AM() {
        Tower t = new Tower(20, 50);
        t.makeInvisible();
        t.pushCup(6);
        t.pushCup(4);
        t.pushCup(2);
        t.pushLid(6);
        t.cover();
        assert t.ok();
        int[] lided = t.lidedCups();
        boolean only6 = lided.length == 1 && lided[0] == 6;
        assert only6 : "Solo debe estar tapada la copa 6";
    }

    /**
     * cover en torre vacía debe fallar con ok() en false.
     * DC
     */
    public static void testCoverEmptyTowerFails_DC() {
        Tower t = new Tower(20, 50);
        t.makeInvisible();
        t.cover();
        assert !t.ok();
    }

    /**
     * cover con copa sin tapa en la torre no la tapa y ok() es true si hay al menos una.
     * AM
     */
    public static void testCoverSkipsCupsWithoutLid_AM() {
        Tower t = new Tower(20, 50);
        t.makeInvisible();
        t.pushCup(3);
        t.pushCup(5);
        t.pushLid(5);
        t.cover();
        assert t.ok();
        int[] lided = t.lidedCups();
        assert lided.length == 1 && lided[0] == 5;
    }

    // swapToReduce — AM, DC

    /**
     * swapToReduce retorna los dos elementos que al intercambiarse reducen la altura.
     * Verificar que al aplicar el swap la altura efectivamente baja.
     * DC
     */
    public static void testSwapToReduceActuallyReduces_DC() {
        Tower t = new Tower(20, 50);
        t.makeInvisible();
        t.pushCup(1);
        t.pushCup(5);
        int heightBefore = t.height();
        String[][] best = t.swapToReduce();
        if (best.length == 2) {
            t.swap(best[0], best[1]);
            assert t.height() <= heightBefore : "La altura debe reducirse o mantenerse";
        }
    }

    /**
     * swapToReduce sobre torre de un solo elemento retorna vacío.
     * AM
     */
    public static void testSwapToReduceOneElementEmpty_AM() {
        Tower t = new Tower(20, 50);
        t.makeInvisible();
        t.pushCup(4);
        assert t.swapToReduce().length == 0;
    }

    /**
     * swapToReduce no modifica la torre (solo consulta).
     * DC
     */
    public static void testSwapToReduceDoesNotModify_DC() {
        Tower t = new Tower(20, 50);
        t.makeInvisible();
        t.pushCup(2);
        t.pushCup(4);
        String[][] before = t.stackingItems();
        t.swapToReduce();
        String[][] after = t.stackingItems();
        assert before[0][1].equals(after[0][1]) : "swapToReduce no debe modificar la torre";
        assert before[1][1].equals(after[1][1]);
    }

    // main

    public static void main(String[] args) {
        testTowerCupsLargestAtBottom_AM();
        testTowerCupsNoLids_DC();

        testSwapVerifyPositions_AM();
        testSwapSameElement_DC();
        testSwapThenCover_AM();

        testCoverAlreadyCovered_DC();
        testCoverNestedCupsOneLid_AM();
        testCoverEmptyTowerFails_DC();
        testCoverSkipsCupsWithoutLid_AM();

        testSwapToReduceActuallyReduces_DC();
        testSwapToReduceOneElementEmpty_AM();
        testSwapToReduceDoesNotModify_DC();

        System.out.println("Todas las pruebas colectivas del Ciclo 2 pasaron.");
    }
}
